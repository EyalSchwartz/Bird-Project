---
title: "The spread of the common Mayna and its effects on local species in Israel"
author: "Eyal Shwartz 205784093  Emmanuel Zackarov 327480323"
output:
  html_document:
    keep_md: yes
  pdf_document: default
---








 







### Introduction 

The Common Myna (Acridotheres tristis) is a songbird native to the tropical regions of South Asia. The species is omnivorous and for that reason it was deliberately moved to different places in the world, mainly for biological and ornamental pest control purposes. The species has a strong tendency to adapt to an urban environment where it competes with native species for food and nesting sites. It was defined by the United Nations as one of the hundred most dangerous invasive species in the world.

The myna was brought to Israel in the 1990s as a pet in the safari compound in Yarkon Park in Tel Aviv, where it escaped from its cage and released itself into the wild. In a short time it spread all over Gush-Dan and even beyond it. In 2015 it was already the fifth bird in Israel in its distribution. Studies carried out at the Hebrew University indicate a great potential of the species to suppress local species. Accordingly, a [study carried out at the Technion](https://www.sciencedirect.com/science/article/pii/S000632071931434X) by Prof. Assaf Schwartz and Dr. Agat Kolanoani indicates a gradual decrease in the distribution of local birds alongside a sharp increase in the distribution of the Mayna in the same areas.

In our opinion, it is important to show the environmental preferences of the species, since knowing these preferences can optimize the fight against their invasion and encourage assistance to local species at the expense of the Mayna.

![The Common Mayna](Mayna.png)


### Research aim

Our goal in this project is to examin for any existing correlation between the increase in the distribution of the species and the decrease in the distribution of prominent local species, and to see if there is a difference between an urban area and a rural area. As a continuation of this, we will examine whether there is any accumulation of environmental conditions that allows the species to flourish in relation to the other species and increases its suppression potential.

Our hypothesis is that we will observe an increase in the relative distribution of the species against a decrease in the distribution of the other species, in accordance with the conclusions of the previous studies carried out in the field. In addition, we expect that the increase in the distribution of the Mayna will be sharper in urban areas compared to rural areas, in light of the research assumption that the Mayna has adapted itself better to life in the human environment.


### Data  

The data used for our research was taken from the BIO-GIS website, which gathers biological information from various sources about the plants and animal species in Israel and presents them visually (in GIS format). As far as for poultry, the information gathered on the site is taken from bird counts carried out by the following sources: the Nature and Parks Authority, the Society for the Protection of Nature and the Israel Ornithological Center. The bird counts themselves were made both by technological means ('Cyber Tracker') and through human observations.

For the research question we wanted to focus on two areas with relatively similar environmental conditions, where what differentiates them is that one is defined as an urban area and the other is defined as a rural area. To this end, we collected observations of the myna and four other local birds [the house sparrow (Passer domesticus), the yellow-bellied nightingale (Pycnonotus xanthopygos), the turd (Turdus merula) and the common woodpecker (Upupa epops)] throughout the city of Tel Aviv-Jaffa (Tel_Aviv Dataset , N = 1032), as well as in open areas in the central district (Open_Areas Dataset, N = 1145), when we defined an open area to be an area with a human influence rate of less than 60%. For each observation record we extracted the following data:

**Species**

**Individuals** - amount of birds in single record

**Collection Date** 

**Record ID** - Serial record code. 

**Data Source** - what source reported the watch.

**MDT1** - average temperature in January at the observation space.

**MDT8** - average temperature in August at the observation space.

**Longitude** 

**Latitude** 

**D2rd** - distance from road at the observation space. 

**Human Impact** - percentage of human impact (ranging 0-100)

**Veg_cover** - percentage of vegetation density (ranging 0-100)

**Rezef** - impact of violated areas on continuity of open spaces  

**Landuse** -  built, open, field, etc.


The observations put to our use regarding the five selected birds are spread over the years 1981-2021, but it seems that for most of these years there is not a large enough amount of observations to allow a proper comparison between the birds.

<img src="figure/manual-unnamed-chunk-3-1.png" style="display: block; margin: auto;" />

For this reason, we chose to focus on the years 2014-2017, for which there seems to be a reasonable amount of observations that allows for analysis.


We also identified that in some months many individuals of birds were observed but in some months there were few, if any, sightings. For us, this means that the sampling effort is not uniform over time. To overcome this we calculated the relative prevalence of each species compared to the other species observed in the same month. We did this by summing up all the individuals observed in a certain month and dividing the monthly amount of each species by this total amount. Doing this leavs us with $\text{N}_\text{Tel-Aviv} = 109$ and $\text{N}_\text{Open-Areas} = 184$. As a follow-up to this, we chose to focus on the monthly trend of the increase or decrease in bird abundance because we assumed that a month is a sufficient time unit to assess the state of the species' abundance based on observations.

For the follow-up question, in order to examine the relationship to the environmental variables, we chose to unite the two datasets and convert each individual bird observation into one sample. For example, if 50 birds of a certain species were observed in a certain observation, then each of the 50 birds will be considered as a separate observation. In this way we hope to create an environmental profile for each bird individually. In this case, we'll be dealing with datasets of the sizes- $\text{N}_\text{all-data} = 14074$.



### Exploratory data analysis (EDA) 


We started our analysis by running a simple linear regression for each bird separately and checking if there is a correlation between the frequency of the bird and the passing time, and how strong that correlation might be (each graph containts the correlation strangth and the matching p-value derived from a correlation test.)

In addition, we examined the strength of the relationship between the regression slopes of the birds by creating a linear regression with Dummy Variables for each species and examining the P-value for the slope differences. 
We performed this test for Tel-Aviv separately and for the open areas separately.

**Tel Aviv multi Linear Model**


```
## 
## Call:
## lm(formula = latency ~ Date * species, data = DS_bymonth_filtered)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -0.38047 -0.11874 -0.04645  0.01732  0.78990 
## 
## Coefficients:
##                                      Estimate Std. Error t value Pr(>|t|)
## (Intercept)                         1.987e+00  1.989e+00   0.999    0.320
## Date                               -8.841e-05  1.192e-04  -0.742    0.460
## speciesPasser domesticus           -2.867e+00  3.218e+00  -0.891    0.375
## speciesPycnonotus xanthopygos       1.071e+00  2.942e+00   0.364    0.717
## speciesTurdus merula               -2.334e+00  3.764e+00  -0.620    0.537
## speciesUpupa epops                 -4.250e+00  3.281e+00  -1.295    0.198
## Date:speciesPasser domesticus       1.694e-04  1.929e-04   0.879    0.382
## Date:speciesPycnonotus xanthopygos -8.281e-05  1.765e-04  -0.469    0.640
## Date:speciesTurdus merula           1.122e-04  2.255e-04   0.498    0.620
## Date:speciesUpupa epops             2.332e-04  1.966e-04   1.186    0.238
## 
## Residual standard error: 0.2157 on 99 degrees of freedom
## Multiple R-squared:  0.434,	Adjusted R-squared:  0.3826 
## F-statistic: 8.436 on 9 and 99 DF,  p-value: 2.933e-09
```

<img src="figure/manual-unnamed-chunk-4-1.png" style="display: block; margin: auto;" />

**Open Areas multi Linear Model**


```
## 
## Call:
## lm(formula = latency ~ Date * species, data = DS_bymonth_filtered)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -0.37244 -0.10889 -0.01687  0.09066  0.65215 
## 
## Coefficients:
##                                      Estimate Std. Error t value Pr(>|t|)    
## (Intercept)                        -3.4818912  1.2273937  -2.837 0.005098 ** 
## Date                                0.0002266  0.0000733   3.091 0.002323 ** 
## speciesPasser domesticus            7.1142509  1.8182735   3.913 0.000131 ***
## speciesPycnonotus xanthopygos       1.2119338  1.7181560   0.705 0.481524    
## speciesTurdus merula                2.7740420  1.7569221   1.579 0.116170    
## speciesUpupa epops                 -2.2714666  1.7168254  -1.323 0.187551    
## Date:speciesPasser domesticus      -0.0004174  0.0001088  -3.835 0.000175 ***
## Date:speciesPycnonotus xanthopygos -0.0000758  0.0001025  -0.739 0.460600    
## Date:speciesTurdus merula          -0.0001789  0.0001050  -1.704 0.090235 .  
## Date:speciesUpupa epops             0.0001245  0.0001024   1.215 0.225852    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.1718 on 174 degrees of freedom
## Multiple R-squared:  0.4535,	Adjusted R-squared:  0.4252 
## F-statistic: 16.04 on 9 and 174 DF,  p-value: < 2.2e-16
```

<img src="figure/manual-unnamed-chunk-5-1.png" style="display: block; margin: auto;" />
At this point it can be seen that in Tel-Aviv there is no clear correlation between any bird and time nor between any of the slopes of the birds. In the open areas, on the other hand, it is possible to see that there is a clear correlation for each bird with time, when it is also possible to clearly indicate a decrease in the frequency of the sparrow compared to an increase in the frequency of the Mayna. But a careful look can show that in some of the graphs there are points that may skew the regression line and this led us to suspect the reliability of the results.

Therefor, After we made the comparison we considered redoing the it taking into account the outliers that might have skewed our correlation. This consideration is made in light of the examination of the base assumptions of linear regression - normality and uniform variance. The normality and homogeneity of the variances were verified visually, and statistically using the Shapiro-Wilk test and the Brusch-Pagan test, before removing the outliers and after removing the outliers. (For each linear model the p-values of the Shapiro-Wilk test and of the Berusch-Pagan test are displayed at the top of the chart.)

**Open Areas Model Diagnostics**

<img src="figure/manual-unnamed-chunk-6-1.png" style="display: block; margin: auto;" /><img src="figure/manual-unnamed-chunk-6-2.png" style="display: block; margin: auto;" />


**Tel-Aviv Model Diagnostics**

<img src="figure/manual-unnamed-chunk-7-1.png" style="display: block; margin: auto;" /><img src="figure/manual-unnamed-chunk-7-2.png" style="display: block; margin: auto;" />

It can now be seen that the base assumptions are not met for any of the data sets, so we will remove the outliers and run the tests again:

**Tel-Aviv with eliminated outliers Model Diagnostics**

<img src="figure/manual-unnamed-chunk-8-1.png" style="display: block; margin: auto;" /><img src="figure/manual-unnamed-chunk-8-2.png" style="display: block; margin: auto;" />

**Open-Areas with eliminated outliers Model Diagnostics**

<img src="figure/manual-unnamed-chunk-9-1.png" style="display: block; margin: auto;" /><img src="figure/manual-unnamed-chunk-9-2.png" style="display: block; margin: auto;" />
It can be seen from the graphs and the results of the statistical tests that now for the majority of the birds we meet the threshold conditions of normality and uniform variance. So now we will perform the linear regressions again for the corrected datasets:

**Tel-Aviv multi Linear Model with eliminated outliers**


```
## 
## Call:
## lm(formula = latency ~ Date * species, data = DS_bymonth_filtered)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -0.26632 -0.05048 -0.00111  0.04613  0.33060 
## 
## Coefficients:
##                                      Estimate Std. Error t value Pr(>|t|)
## (Intercept)                         2.522e-02  1.023e+00   0.025    0.980
## Date                                2.276e-05  6.118e-05   0.372    0.711
## speciesPasser domesticus           -3.774e-01  1.544e+00  -0.244    0.808
## speciesPycnonotus xanthopygos      -7.495e-01  1.473e+00  -0.509    0.612
## speciesTurdus merula               -1.788e-01  1.746e+00  -0.102    0.919
## speciesUpupa epops                  2.014e-01  1.691e+00   0.119    0.905
## Date:speciesPasser domesticus       2.301e-05  9.252e-05   0.249    0.804
## Date:speciesPycnonotus xanthopygos  3.003e-05  8.814e-05   0.341    0.734
## Date:speciesTurdus merula          -1.150e-05  1.046e-04  -0.110    0.913
## Date:speciesUpupa epops            -3.377e-05  1.013e-04  -0.333    0.740
## 
## Residual standard error: 0.09533 on 84 degrees of freedom
## Multiple R-squared:  0.7671,	Adjusted R-squared:  0.7421 
## F-statistic: 30.73 on 9 and 84 DF,  p-value: < 2.2e-16
```

<img src="figure/manual-unnamed-chunk-10-1.png" style="display: block; margin: auto;" />
**Open Areas multi Linear Model with eliminated outliers**


```
## 
## Call:
## lm(formula = latency ~ Date * species, data = DS_bymonth_filtered)
## 
## Residuals:
##      Min       1Q   Median       3Q      Max 
## -0.34309 -0.06563 -0.01327  0.06962  0.35529 
## 
## Coefficients:
##                                      Estimate Std. Error t value Pr(>|t|)   
## (Intercept)                        -1.636e+00  9.366e-01  -1.747  0.08253 . 
## Date                                1.145e-04  5.603e-05   2.043  0.04264 * 
## speciesPasser domesticus            4.241e+00  1.378e+00   3.078  0.00245 **
## speciesPycnonotus xanthopygos       2.396e-01  1.307e+00   0.183  0.85471   
## speciesTurdus merula                1.471e+00  1.341e+00   1.097  0.27437   
## speciesUpupa epops                  1.445e+00  1.446e+00   1.000  0.31885   
## Date:speciesPasser domesticus      -2.444e-04  8.250e-05  -2.963  0.00351 **
## Date:speciesPycnonotus xanthopygos -1.736e-05  7.806e-05  -0.222  0.82430   
## Date:speciesTurdus merula          -9.961e-05  8.026e-05  -1.241  0.21638   
## Date:speciesUpupa epops            -1.012e-04  8.663e-05  -1.168  0.24439   
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## Residual standard error: 0.1245 on 161 degrees of freedom
## Multiple R-squared:  0.5884,	Adjusted R-squared:  0.5654 
## F-statistic: 25.58 on 9 and 161 DF,  p-value: < 2.2e-16
```

<img src="figure/manual-unnamed-chunk-11-1.png" style="display: block; margin: auto;" />


The results obtained this time show that in Tel-Aviv it is not possible to indicate a clear correlation with time for any bird, and in addition it is also not possible to identify a clear difference between the slopes of the regression lines of any bird. As for the open areas, it is also not possible to indicate a clear correlation between the distribution of the bird and the passing time for any bird, but a clear difference in the slope between the mayna and the sparrow bird can be identified, meaning that there is a clear correlation between the increase in the distribution of the mayna over time and the decrease in the distribution of the sparrow over time.

At this stage we needed to address the fact that the sampling effort is not uniform throughout the years 2014-2017 (as you can see in the graph above), and we needed to find a way to compensate for this gap to make sure that the results obtained do indeed reflect reality and that there is no bias in the trend depending on the changing sampling effort. We chose to perform bootstrapping for the correlation of the frequency of each species with the passing time as well as for the magnitude of the slope, and compare them to the corresponding values we actually received.

**Open Areas correlation Bootstraping**


```
## [1] "Acridotheres tristis"
## [1] "MEAN is  0.257189776714866"
## [1] "SD   is  0.125845546476136"
## [1] "Passer domesticus"
## [1] "MEAN is  -0.270090965283141"
## [1] "SD   is  0.159011547303184"
## [1] "Pycnonotus xanthopygos"
## [1] "MEAN is  0.255317846993989"
## [1] "SD   is  0.186387831297928"
## [1] "Turdus merula"
## [1] "MEAN is  0.0815807202666648"
## [1] "SD   is  0.203245395198794"
## [1] "Upupa epops"
## [1] "MEAN is  0.130899883003189"
## [1] "SD   is  0.276602786485498"
```

<img src="figure/manual-unnamed-chunk-12-1.png" style="display: block; margin: auto;" />

**Open Areas slope Bootstraping**


```
## [1] "Acridotheres tristis"
## [1] "MEAN is  0.00343942000982241"
## [1] "SD   is  0.00185074613989463"
## [1] "Passer domesticus"
## [1] "MEAN is  -0.00392301206500133"
## [1] "SD   is  0.00243163753544263"
## [1] "Pycnonotus xanthopygos"
## [1] "MEAN is  0.00273295277958483"
## [1] "SD   is  0.00199729085622468"
## [1] "Turdus merula"
## [1] "MEAN is  0.000454776554659557"
## [1] "SD   is  0.00107036029981084"
## [1] "Upupa epops"
## [1] "MEAN is  0.000391111376375822"
## [1] "SD   is  0.000864913847847403"
```

<img src="figure/manual-unnamed-chunk-13-1.png" style="display: block; margin: auto;" />

**Tel Aviv correlation Bootstraping**


```
## [1] "Acridotheres tristis"
## [1] "MEAN is  0.0331910855033447"
## [1] "SD   is  0.271141179983208"
## [1] "Passer domesticus"
## [1] "MEAN is  0.119549181592305"
## [1] "SD   is  0.178012841384706"
## [1] "Pycnonotus xanthopygos"
## [1] "MEAN is  0.211264295155062"
## [1] "SD   is  0.220820155724909"
## [1] "Turdus merula"
## [1] "MEAN is  0.216931195264146"
## [1] "SD   is  0.332983886175612"
## [1] "Upupa epops"
## [1] "MEAN is  -0.0645315122838676"
## [1] "SD   is  0.264530622595174"
```

<img src="figure/manual-unnamed-chunk-14-1.png" style="display: block; margin: auto;" />
**Tel Aviv slope Bootstraping**


```
## [1] "Acridotheres tristis"
## [1] "MEAN is  0.000626573191141954"
## [1] "SD   is  0.00324486865627637"
## [1] "Passer domesticus"
## [1] "MEAN is  0.00116079101180838"
## [1] "SD   is  0.00191311915402002"
## [1] "Pycnonotus xanthopygos"
## [1] "MEAN is  0.00172154429291268"
## [1] "SD   is  0.00178605274467605"
## [1] "Turdus merula"
## [1] "MEAN is  0.000300566785131833"
## [1] "SD   is  0.000472432454722872"
## [1] "Upupa epops"
## [1] "MEAN is  -0.00029653071437093"
## [1] "SD   is  0.000728803527822914"
```

<img src="figure/manual-unnamed-chunk-15-1.png" style="display: block; margin: auto;" />

Comparing the average of the bootstrapping results for the correlations to the correlations we actually found shows that in all cases the correlation we found is within one standard deviation of the obtained average, which can potentially indicate the reliability of the observations collected despite the changing sampling effort. For the slopes the picture is relatively similar, except that in Tel-Aviv for some of the birds the bootstrapping suggests that the gradients we found are underestimated, but as mentioned, the matter is less important in the absence of a clear correlation with time. It turns out that if the facts are correct, then at this stage it is not possible to point to a reliable correlation between an increase in the distribution of the Mayna and a decrease in the frequency of the other birds, neither in Tel-Aviv nor in the open areas.

### PCA analysis

At this point, after we have come to see that in most cases we are unable to confirm the correlation between the spread of the Mayna and the decline of the local birds, we are required to attend to our second question - is it possible to point to a certain set of environmental conditions that allow the prosperity of the Mayna compared to other sets. For this we will try to create Classifiers in a way that can distinguish as accurately as possible between the Mayna and the other species. 

The optional predictors we will use are the ones that can give us an indication of the environmental profile of the bird (for this reason, for example - we will omit a predictor such as the Record ID which is not really capable of giving us an indication of the environment in which the bird was observed). Therefore we will only use the following predictors: MDT1, MDT8, longitude, latitude, d2rd, human_impact, veg_cover, rezef and landuse. In order to perform the classification, we will create Test-Train Splits and then use the following methods:

**Glm (Full Model)** - using logistic regression that uses all the existing predictors.

**Glm (selected model)** - logistic regression using the AIC method, with a two-way progress.

**PCA** (for the numerical predictors only)


We will rank the models using their level of accuracy so that the most accurate model could hopefully teach us about the environmental preferences of the Mayna. 

First we will compare the distribution of each of the environmental variables for the Mayna compared to the other birds and see if we can see visual evidence of a difference between the two groups (TRUE indicating as Mayna and FALSE indicating as Not-A-Mayna)-

<img src="figure/manual-unnamed-chunk-16-1.png" style="display: block; margin: auto;" />

From the graphs it can be seen that the main difference between the groups exists in the veg_cover, rezef and d2rd parameters, in a way that may imply that the Mayna is more common in areas with a lower vegetation density and in areas further from the road, compared to the other bird species. Also, it is possible that the other bird species will prefer areas that are not part of a continuum of open areas to a much greater extent than the Mayna.

Now we will create a generalized Linear Model of a Binomial type on all the environmental variables to create a classification of our Train Data. As a continuation of this, the predictors were diluted in the aspect of AIC in a two-way progression. We will actually stay with the following model: (show Coeffs). 


```
## 
## Call:
## glm(formula = Mayna ~ mdt1 + mdt8 + longitude + veg_cover + rezef + 
##     landuse, family = "binomial", data = training)
## 
## Deviance Residuals: 
##     Min       1Q   Median       3Q      Max  
## -2.1608  -0.9519  -0.8302   1.2919   2.7345  
## 
## Coefficients:
##                                   Estimate Std. Error z value Pr(>|z|)    
## (Intercept)                     -2.426e+02  3.247e+01  -7.472 7.89e-14 ***
## mdt1                             3.402e+00  1.900e-01  17.906  < 2e-16 ***
## mdt8                            -9.743e-01  2.425e-01  -4.018 5.87e-05 ***
## longitude                        6.476e+00  1.004e+00   6.449 1.12e-10 ***
## veg_cover                       -1.953e-02  1.957e-03  -9.981  < 2e-16 ***
## rezef                            1.393e-03  1.485e-04   9.383  < 2e-16 ***
## landuseBuilt - public buildings  1.731e-01  2.393e-01   0.723    0.470    
## landuseBuilt - Residence        -6.805e-02  2.322e-01  -0.293    0.769    
## landuseCultivated fields         1.702e+00  2.493e-01   6.825 8.81e-12 ***
## landuseForest                    4.219e-01  2.652e-01   1.591    0.112    
## landuseOpen area                -1.446e-01  2.290e-01  -0.631    0.528    
## landuseOrchards                 -2.330e-01  2.771e-01  -0.841    0.400    
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## (Dispersion parameter for binomial family taken to be 1)
## 
##     Null deviance: 9287  on 7037  degrees of freedom
## Residual deviance: 8618  on 7026  degrees of freedom
## AIC: 8642
## 
## Number of Fisher Scoring iterations: 4
```

It also appears that the sparse model has a slightly better AIC score than the full model.

**Full model AIC**


```
## [1]   15.000 8647.262
```

**Full model AIC**


```
## [1]   12.000 8642.036
```

We will also confirm this using the ANOVA test (High p-value means preferring a smaller model):


```
## Analysis of Deviance Table
## 
## Model 1: Mayna ~ mdt1 + mdt8 + longitude + veg_cover + rezef + landuse
## Model 2: Mayna ~ mdt1 + mdt8 + longitude + latitude + d2rd + human_impact + 
##     veg_cover + rezef + landuse
##   Resid. Df Resid. Dev Df Deviance Pr(>Chi)
## 1      7026     8618.0                     
## 2      7023     8617.3  3  0.77427   0.8556
```
Now, after we have seen that the sparse model is better in terms of its weight, we will examine the practical difference between the two models using the Confusion Matrix:

**Full model accuracy**


```
## Confusion Matrix and Statistics
## 
##          actual
## predicted FALSE TRUE
##     FALSE  4220 2192
##     TRUE    202  422
##                                           
##                Accuracy : 0.6597          
##                  95% CI : (0.6485, 0.6708)
##     No Information Rate : 0.6285          
##     P-Value [Acc > NIR] : 2.551e-08       
##                                           
##                   Kappa : 0.1371          
##                                           
##  Mcnemar's Test P-Value : < 2.2e-16       
##                                           
##             Sensitivity : 0.9543          
##             Specificity : 0.1614          
##          Pos Pred Value : 0.6581          
##          Neg Pred Value : 0.6763          
##              Prevalence : 0.6285          
##          Detection Rate : 0.5998          
##    Detection Prevalence : 0.9113          
##       Balanced Accuracy : 0.5579          
##                                           
##        'Positive' Class : FALSE           
## 
```

**Sparse model accuracy**


```
## Confusion Matrix and Statistics
## 
##          actual
## predicted FALSE TRUE
##     FALSE  4220 2192
##     TRUE    202  422
##                                           
##                Accuracy : 0.6597          
##                  95% CI : (0.6485, 0.6708)
##     No Information Rate : 0.6285          
##     P-Value [Acc > NIR] : 2.551e-08       
##                                           
##                   Kappa : 0.1371          
##                                           
##  Mcnemar's Test P-Value : < 2.2e-16       
##                                           
##             Sensitivity : 0.9543          
##             Specificity : 0.1614          
##          Pos Pred Value : 0.6581          
##          Neg Pred Value : 0.6763          
##              Prevalence : 0.6285          
##          Detection Rate : 0.5998          
##    Detection Prevalence : 0.9113          
##       Balanced Accuracy : 0.5579          
##                                           
##        'Positive' Class : FALSE           
## 
```
In fact, it can be seen that the sparse model is not alot more accurate than the full model. In any case, it can be seen from the summary of the model that there are several factors that clearly affect classification with an accuracy level of 65.97%: mdt1, mdt8, longitude, veg_cover, rezef and cultivated fields. That is, we can say for a start that the identification from the density plots was not far from reality. However, it cannot be ignored that this is still not a particularly high level of accuracy. That is, the interim conclusion is that although there are differences in the environmental profile of the Mayna and other birds, it is still not a particularly large difference.

## PCA{.smaller}

The next step is to test the PCA model. Using this model we will reduce the dimension of the predictors of our data and see through the two-dimensional projection which of the predictors have the greatest effect on the frequency of the bird.
Using a scree plot it seems that about 65% of the variation is explained by the first two dimensions, hence we will focus on these two dimensions to explain the spread of the information.

<img src="figure/manual-unnamed-chunk-23-1.png" style="display: block; margin: auto;" />

Now, since PCA is not a tool originaly designed for classification, we will look for another method to test its reliability. We will create two PCA models, one for the Train dataset and one for the Test dataset. We will draw an ellipse that will combine the identifications of the Mayna and the non-Maynas at a significance level of 95% and we will analyze the tendency of the ellipses.

<img src="figure/manual-unnamed-chunk-24-1.png" style="display: block; margin: auto;" />

It can be observed that for both models the variation of the other birds is greater than the variation of the species, which is expressed in a larger radius of the ellipse. Also, the ellipse describing the rest of the birds is drawn in the positive direction of dim.1 compared to the ellipse of the Mayna, which may imply an increased influence of the variables in dim1 on the characterization of the rest of the birds. In order to compare the degree of influence of the variables on the composition of the first dimension, we will look at the coordinates of the variables and also at the cos2 index, which refers to the degree of representation of a variable in a certain dimension.


```
##                    Dim.1       Dim.2       Dim.3       Dim.4       Dim.5
## mdt1         -0.87342262  0.33430564  0.11538652 -0.11990358 -0.06043934
## mdt8          0.88722535  0.18535190 -0.03526447  0.07726492 -0.06439970
## longitude     0.87069956  0.17998336  0.19852499  0.38507079 -0.10462463
## latitude     -0.52461347  0.51396581  0.51196742  0.38083995 -0.19032244
## d2rd          0.01865956 -0.08699718  0.92989332 -0.27965653  0.13343936
## human_impact -0.71577105  0.43071673 -0.29059842  0.24334785  0.29838458
## veg_cover     0.20315518  0.81317351 -0.20634269 -0.39445638 -0.27288462
## rezef         0.63074215  0.61067846  0.07033675 -0.07805032  0.41557696
```

<img src="figure/manual-unnamed-chunk-25-1.png" style="display: block; margin: auto;" />
 
 We received that the leading variables in the composition of the first dimension are (in descending order) mdt1 (downward trend), mdt8 (rising trend), longitude (rising trend), rezef (rising trend), veg_cover (rising trend), similar to the effect observed in the logistic regression and the one suggested in the density plots. This means that the results of the PCA reinforce the results we received from the logistic regression model and indicate that the Mayna is most commonly identified with temperature, when it will prefer areas with a high average temperature in the winter and a low average temperature in summer, i.e. areas with a more temperate climate. In a less common way, it will prefer more western areas, that is, closer to the sea, and in an even less common way, it will prefer a low vegetation density and a high succession of open areas.
 
### Conclusion

In this article, we tried to examine the extent and nature of the species penetration into the natural intricacies of the Land of Israel. As we mentioned above, the Mayna is a bird that has a particularly destructive potential towards local species, as it is a firm competition against them for nesting places and food sources, and for which reason it is considered an extremely destructive invasive species. Studies done in the field indicate an increased ability of the species to suppress some of the local species in the areas it invades, which is reflected in an increase in the prevalence of the Mayna along with a decrease in the prevalence of those local species.

Accordingly, we tried to reproduce some of the results of those studies by identifying the correlation between the increase in the prevalence of the Mayna and the decrease in the prevalence of other species, alongside a distinction we hoped to add between the trend in an urban area and the trend in a rural area. As a continuation, we hoped to characterize the environmental profile to which the Mayna is attracted especially in order to provide information that will be of help to the bodies fighting the spread of the species.

The results we received indicate that it is not possible to clearly point to any correlation with the time of the frequency of the species, nor of any bird to be honest, neither in Tel-Aviv nor in the open areas. Furthermore, we were also unable to show that there is any correlation between the behaviors of the bird populations. 
We hypothesize that part of the reason we were unable to reproduce the results of the previous studies is because the data that was available to us was concentrated in a relatively short span of years, while in the study of Prof. Assaf Schwartz and Dr. Agath Kolnoani, for example, they examined the behaviors of the bird populations over nearly 20 years It is also possible that the data collected does not faithfully represent the distribution of the birds in reality, because perhaps the database we used contains inherent biases that prioritize the documentation of one bird over the other (perhaps out of a tendency to appeal to the database's user audience) in contrast to the above study that diversified the data it has by using in three separate repositories.

In a second step, we tried to identify the environmental preference of the species compared to different local birds. We found out through different models (Logistic Regression and PCA) that there are some environmental criteria that can be used to give a kind of prediction about whether the bird is a Mayna or not. Among other things, we found with a high level of significance that the Mayna will prefer a more temperate climate compared to local species, it will prefer proximity to the sea (from the perspective of the central region) and it will also prefer open areas but sparse vegetation cover.The tendency to a temperate climate can be explained by the fact that this is a bird that originates in tropical areas, and perhaps for this reason it will also prefer proximity to the sea, due to the humidity associated with it. The tendency towards open and sparsely vegetated areas, although it is not strong compared to the previous tendencies, does not naturally fit with our assumption that the Mayna will prefer the environment of humans over open areas. It could be said that the sampling effort in open areas tipped the scales in favor of this tendency. It can also be said that the choice to narrow down to the Greater Central area may not have allowed for a large enough sampling space, since the conditions there are relatively the same (compared to the rest of the country) and do not allow for a large variation that could indicate a clear trend in identification.

We are full of hope that some of the information we have shed here on the distribution of the minnow in the Land of Israel can be of help to the relevant parties with the aim of reducing as much as possible the impact of this species on the fragile ecosystem that is a home for all of us.


